Supporting Information — reproducibility package
"Diminishing returns of quantum chemistry in blood-brain barrier permeability
prediction: a scaffold-split benchmark against fingerprints and DFT"

Everything needed to reproduce every number and figure in the manuscript.
All inputs derive from the public B3DB database; no data is restricted.

data/
  SMILES.csv                 7,575 analysed compounds: SMILES, InChIKey, name,
                             BBB class label, numeric logBB where available,
                             molecular weight, Bemis-Murcko scaffold. Machine
                             readable; loads directly into RDKit or pandas.

descriptors/
  gfn2_ladder_L3.csv         semi-empirical ladder, levels 1-3, all compounds:
                             solvation free energies (water, octanol,
                             hexadecane), transfer free energies, total energy,
                             HOMO, LUMO, gap, dipole, plus the 11 classical
                             RDKit descriptors used as the baseline.
  gfn2_descriptors.csv       per-molecule GFN2-xTB electronic descriptors.
  gfn2_solvation.csv         per-molecule solvation terms by phase.
  dft_results_merged.csv     B3LYP/def2-SVP with SMD solvation, 7,572 molecules
                             x 35 columns, zero non-converged SCF: gas, water,
                             octanol and hexadecane single points on the fixed
                             GFN2 geometries, with the derived solvation and
                             transfer free energies and frontier orbitals.

predictions/
  all_oof.npz                out-of-fold predictions for every feature set
                             under the Bemis-Murcko scaffold-grouped 5-fold
                             partition. Every AUC, PR-AUC and bootstrap
                             interval in the paper is computed from this file,
                             so all derived statistics come from one partition.
  final_analysis.json        the computed metrics behind Tables 1-3.
  orbital_shape.csv          frontier-orbital shape descriptors (inverse
                             participation ratios, spatial extents, isotropic
                             polarisability) for the Section 3.4 comparison.

code/
  curate.py                  B3DB parsing, standardisation to the largest
                             covalent fragment, element restriction, 5-70
                             heavy-atom window, InChIKey deduplication.
  descriptors_ladder.py      GFN2-xTB levels 1-3 (xtb, ALPB solvation).
  run_dft.py                 B3LYP/def2-SVP single points with SMD (PySCF).
  ladder_analysis.py         the cost-accuracy ladder.
  final_analysis.py          scaffold-grouped CV, paired bootstrap, all headline
                             numbers.
  homo_attribution.py        leave-one-descriptor-out attribution (Section 3.4).
  geom_study.py              per-phase geometry relaxation control (Section 2.2).
  make_fig1.py               regenerates Figure 1 from all_oof.npz.

Software: RDKit, xtb, PySCF, scikit-learn, numpy, scipy — all open source.
The DFT arm used GPU4PySCF; the semi-empirical arm runs on CPU, and was in fact
produced on a Raspberry Pi 4.
