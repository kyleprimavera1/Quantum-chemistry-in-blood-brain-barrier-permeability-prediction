#!/usr/bin/env python3
"""Does reoptimising at B3LYP change the DFT descriptors?

This is the one untested assumption left in the level-4 control. Every B3LYP
single point in that control was evaluated on a GFN2-optimised geometry, so the
equivalence it reports is conditional: DFT electronic structure on semi-empirical
coordinates. The hostile reading is that both arms inherit the same geometric
distortion and equivalence follows by construction.

The test is deliberately self-contained rather than reusing the production
geometries, because the question is internal: for the SAME molecule, does moving
from a GFN2 geometry to a B3LYP geometry move the descriptors?

  geometry A = RDKit ETKDG -> MMFF -> GFN2 optimisation (as in the main ladder)
  geometry B = B3LYP/def2-SVP optimisation started from A
  descriptors computed identically on both: 4 SMD single points

The decisive comparison is not "is the shift zero" - it will not be - but whether
the GEOMETRY perturbation is small relative to the HAMILTONIAN perturbation
already measured in 3.9 (HOMO r = 0.881, dG_transfer r = 0.709 between GFN2 and
DFT). If geometry moves the descriptors far less than the Hamiltonian does, then
holding geometry fixed cannot be what produced the equivalence.

CPU PySCF throughout: no GPU toolchain to match, and at this sample size the
wall-clock is affordable. SMD on both, matching the production run.
"""
import argparse, base64, csv, gzip, json, os, re, subprocess, sys, tempfile, time
from multiprocessing import Pool

ap = argparse.ArgumentParser()
ap.add_argument("--blob", required=True, help="b64+gzip JSON list of [id, smiles]")
ap.add_argument("--procs", type=int, default=8)
ap.add_argument("--threads", type=int, default=2)
ap.add_argument("--maxsteps", type=int, default=10)
a = ap.parse_args()

import numpy as np
from rdkit import Chem, RDLogger
from rdkit.Chem import AllChem
RDLogger.DisableLog("rdApp.*")

EPS = {"water": 78.3553, "octanol": 9.8629, "hexadecane": 2.0402}
SMD = {"water": "water", "octanol": "1-octanol", "hexadecane": "n-hexadecane"}
HK = 627.5094740631
RE_HOMO = re.compile(r"^\s*\d+\s+[\d.]+\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s*\(HOMO\)", re.M)


def gfn2_geometry(smi, chrg):
    """Geometry A: the main ladder's recipe."""
    m = Chem.MolFromSmiles(smi)
    if m is None: return None
    mh = Chem.AddHs(m)
    if AllChem.EmbedMolecule(mh, randomSeed=42, useRandomCoords=True) != 0: return None
    AllChem.MMFFOptimizeMolecule(mh, maxIters=500)
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "m.xyz")
        c = mh.GetConformer()
        with open(p, "w") as f:
            f.write("%d\n\n" % mh.GetNumAtoms())
            for at in mh.GetAtoms():
                q = c.GetAtomPosition(at.GetIdx())
                f.write("%s %.8f %.8f %.8f\n" % (at.GetSymbol(), q.x, q.y, q.z))
        r = subprocess.run(["xtb", "m.xyz", "--gfn", "2", "--opt", "--alpb", "water",
                            "--chrg", str(chrg)], cwd=d, capture_output=True,
                           text=True, timeout=1800)
        if r.returncode != 0: return None
        opt = os.path.join(d, "xtbopt.xyz")
        if not os.path.exists(opt): return None
        lines = open(opt).read().splitlines()
    n = int(lines[0])
    atoms = [(l.split()[0], list(map(float, l.split()[1:4]))) for l in lines[2:2+n]]
    return atoms


def descriptors(atoms, chrg, optimise):
    """Four SMD single points; optionally B3LYP-optimise the geometry first."""
    from pyscf import gto, dft, lib
    lib.num_threads(1)   # one thread per worker; concurrency comes from the pool
    mol = gto.M(atom=[(s, tuple(x)) for s, x in atoms], basis="def2-svp",
                charge=chrg, spin=0, verbose=0)
    opt_env = ""
    if optimise:
        # The B3LYP reoptimisation MUST be solvated. Geometry A is optimised by
        # xtb in implicit water (--alpb water); optimising B in the gas phase
        # would confound the Hamiltonian change with an environment change, and
        # would do so in the worst direction: gas-phase optimisation collapses
        # polar flexible drug molecules into intramolecular hydrogen-bonded
        # conformers that do not exist in solution, inflating the apparent
        # geometry effect this study exists to measure.
        #
        # SMD is preferred so the optimisation matches the water single point.
        # If SMD gradients are unavailable in this PySCF build, fall back to
        # C-PCM: geometries are far less sensitive to the choice of continuum
        # model than energies are. Whichever was used is recorded per row.
        # DISPERSION IS MANDATORY HERE. Geometry A comes from GFN2-xTB, which
        # carries D4. Optimising geometry B with bare B3LYP would compare a
        # dispersion-corrected geometry against an uncorrected one and attribute
        # the difference to "level of theory" - exactly the confound this study
        # exists to avoid. B3LYP without dispersion systematically
        # under-stabilises folded conformers, so a flexible molecule that GFN2
        # correctly folds would be unfolded by the reoptimisation and the study
        # would report a dispersion artefact as a geometry effect.
        from pyscf.geomopt.geometric_solver import optimize
        mf = dft.RKS(mol); mf.xc = "b3lyp"; mf.disp = "d3bj"; mf.conv_tol = 1e-9
        try:
            mfs = mf.SMD(); mfs.with_solvent.solvent = "water"
            mol = optimize(mfs, maxsteps=a.maxsteps); opt_env = "SMD/water+D3BJ"
        except Exception:
            mf2 = dft.RKS(mol); mf2.xc = "b3lyp"; mf2.disp = "d3bj"
            mf2.conv_tol = 1e-9
            mfp = mf2.PCM(); mfp.with_solvent.method = "C-PCM"
            mfp.with_solvent.eps = EPS["water"]
            mol = optimize(mfp, maxsteps=a.maxsteps); opt_env = "C-PCM/water+D3BJ"
    out = {}
    # D3 is applied to the single points too, so the protocol is uniformly
    # B3LYP-D3(BJ)/def2-SVP. It is numerically INERT for every descriptor below:
    # D3 depends only on nuclear positions and atom types, never on the SCF
    # density or the dielectric, so for a fixed geometry it takes the same value
    # in all four phases and cancels identically in Gsolv and dG_transfer. It
    # also never enters the Fock matrix, so HOMO/LUMO/gap/dipole are unchanged.
    # It is set for consistency with the optimisation, not to change a number.
    for phase in ("gas", "water", "octanol", "hexadecane"):
        mf = dft.RKS(mol); mf.xc = "b3lyp"; mf.disp = "d3bj"; mf.conv_tol = 1e-9
        if phase != "gas":
            mf = mf.SMD(); mf.with_solvent.solvent = SMD[phase]
        e = mf.kernel()
        if not mf.converged: return None
        if phase == "water":
            occ = mf.mo_occ > 0
            out["homo"] = float(mf.mo_energy[occ][-1] * 27.211386)
            out["lumo"] = float(mf.mo_energy[~occ][0] * 27.211386)
            out["dipole"] = float(np.linalg.norm(mf.dip_moment(unit="Debye", verbose=0)))
        out["e_" + phase] = float(e)
    g = {"gsolv_water": (out["e_water"] - out["e_gas"]) * HK,
         "gsolv_oct":   (out["e_octanol"] - out["e_gas"]) * HK,
         "gsolv_hxd":   (out["e_hexadecane"] - out["e_gas"]) * HK}
    g["dg_transfer"] = g["gsolv_oct"] - g["gsolv_water"]
    g["dg_hxd"] = g["gsolv_hxd"] - g["gsolv_water"]
    g["dlogp"] = g["dg_hxd"] - g["dg_transfer"]
    g["opt_env"] = opt_env
    g["homo"], g["lumo"] = out["homo"], out["lumo"]
    g["gap"] = out["lumo"] - out["homo"]; g["dipole"] = out["dipole"]
    return g


def work(rec):
    mid, smi = rec
    t0 = time.time()
    try:
        chrg = Chem.GetFormalCharge(Chem.MolFromSmiles(smi))
        atoms = gfn2_geometry(smi, chrg)
        if atoms is None: return dict(mol_id=mid, ok=0, err="geometry")
        A = descriptors(atoms, chrg, optimise=False)
        if A is None: return dict(mol_id=mid, ok=0, err="scf_A")
        B = descriptors(atoms, chrg, optimise=True)
        if B is None: return dict(mol_id=mid, ok=0, err="scf_B")
        r = dict(mol_id=mid, ok=1, err="", n_atoms=len(atoms),
                 secs=round(time.time()-t0, 1), opt_env=B.get("opt_env", ""))
        for k in A:
            if k == "opt_env": continue
            r["A_" + k] = A[k]; r["B_" + k] = B[k]
        return r
    except Exception as e:
        return dict(mol_id=mid, ok=0, err="%s:%s" % (type(e).__name__, str(e)[:60]))


def _require_dispersion():
    """Abort if the D3 backend is missing.

    Without it PySCF raises only when the first energy is evaluated, deep inside
    a worker, where the pool's exception handling would record it as a per-
    molecule failure and the run would continue producing dispersion-free
    geometries. That is the one failure mode this study cannot tolerate, so it
    is checked once, in the parent, before any work starts.
    """
    from pyscf import gto, dft
    m = gto.M(atom="He 0 0 0", basis="sto-3g", verbose=0)
    mf = dft.RKS(m); mf.xc = "b3lyp"; mf.disp = "d3bj"
    mf.kernel()


def main():
    _require_dispersion()
    recs = json.loads(gzip.decompress(base64.b64decode(a.blob)).decode())
    print("GEOM STUDY %d molecules, %d procs x %d threads" % (len(recs), a.procs, a.threads), flush=True)
    # The smoke test runs INSIDE the pool, not in the parent.
    #
    # Running it in the parent initialises PySCF's threaded BLAS/OpenMP, and
    # forking a process that already holds OpenMP locks deadlocks every child:
    # the parent completes, no worker ever produces output, and nothing raises.
    # That is exactly what happened on the first two attempts - eight optimiser
    # step lines, all from the single molecule the parent computed.
    #
    # Fail-fast is preserved by aborting on the FIRST result to come back rather
    # than by computing one molecule up front.
    res, first = [], True
    with Pool(a.procs, maxtasksperchild=1) as p:
        for r in p.imap_unordered(work, recs, chunksize=1):
            if first:
                first = False
                if not r.get("ok"):
                    print("FIRST RESULT FAILED -> abort: %s" % r.get("err"), flush=True)
                    raise SystemExit(2)
                print("first result ok: A_homo=%.4f B_homo=%.4f (%.0f s)"
                      % (r["A_homo"], r["B_homo"], r["secs"]), flush=True)
            res.append(r); print("REC " + json.dumps(r), flush=True)
    print("DONE ok=%d/%d" % (sum(x.get("ok", 0) for x in res), len(res)), flush=True)


if __name__ == "__main__":
    main()
