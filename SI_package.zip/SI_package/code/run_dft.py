#!/usr/bin/env python3
"""Level-4 control: B3LYP/def2-SVP single points on pre-optimised GFN2 geometries.

Reads geometries/*.xyz, writes dft_results.csv. Resumable - re-running skips
molecules already present in the output file.

  python run_dft.py --threads 4 --memory 8000
"""
import argparse, csv, glob, os, sys, time

ap = argparse.ArgumentParser()
ap.add_argument("--threads", type=int, default=4,
                help="CPU threads. IMPORTANT: leave cores free if this machine "
                     "is running an MD simulation - GPU MD still needs CPU.")
ap.add_argument("--memory", type=int, default=8000, help="max memory in MB")
ap.add_argument("--geom-dir", default="geometries")
ap.add_argument("--out", default="dft_results.csv")
ap.add_argument("--basis", default="def2-svp")
ap.add_argument("--functional", default="b3lyp")
ap.add_argument("--solvent", default="water",
                choices=["water","octanol","hexadecane","gas"],
                help="implicit solvent (ddCOSMO). MUST match the GFN2 reference, "
                     "which used implicit WATER. Gas phase shifts dipoles ~28%.")
a = ap.parse_args()

import csv as _csv
import numpy as np
from pyscf import gto, dft, lib

# Formal charges must come from the reference table. Without them PySCF assumes
# neutral, silently computing the wrong electron count for charged species.
CHARGE = {}
with open("gfn2_descriptors.csv") as _f:
    for _r in _csv.DictReader(_f):
        CHARGE[_r["inchikey"]] = int(_r["charge"])
lib.num_threads(a.threads)

# dielectric constants at 298 K
EPS = {"water": 78.3553, "octanol": 9.8629, "hexadecane": 2.0402, "gas": None}

FIELDS = ["inchikey","n_atoms","nao","charge","solvent","dft_homo_eV","dft_lumo_eV","dft_gap_eV",
          "dft_dipole_D","dft_energy_Ha","converged","seconds","error"]

done = set()
if os.path.exists(a.out):
    with open(a.out) as f:
        done = {r["inchikey"] for r in csv.DictReader(f)}

files = sorted(glob.glob(os.path.join(a.geom_dir, "*.xyz")))
todo = [f for f in files if os.path.splitext(os.path.basename(f))[0] not in done]
print(f"{len(files)} geometries, {len(done)} already done, {len(todo)} to run")
print(f"threads={a.threads}  memory={a.memory} MB  {a.functional}/{a.basis}"
      f"  solvent={a.solvent}"
      f"{' (eps=%.2f)' % EPS[a.solvent] if EPS[a.solvent] else ' (VACUUM - does not match the GFN2 reference)'}\n")

new = not os.path.exists(a.out) or os.path.getsize(a.out) == 0
t_start = time.time()
with open(a.out, "a", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=FIELDS)
    if new: w.writeheader(); fh.flush()
    for i, path in enumerate(todo, 1):
        key = os.path.splitext(os.path.basename(path))[0]
        row = {"inchikey": key, "solvent": a.solvent, "error": ""}
        t0 = time.time()
        try:
            lines = open(path).read().splitlines()
            n = int(lines[0])
            atoms = [(p[0], (float(p[1]), float(p[2]), float(p[3])))
                     for p in (l.split() for l in lines[2:2+n])]
            chg = CHARGE.get(key, 0)
            # gto.M() builds immediately and rejects an odd electron count with
            # spin=0, so the multiplicity must be settled BEFORE building.
            nelec = sum(gto.charge(sym) for sym, _ in atoms) - chg
            mol = gto.Mole()
            mol.atom = atoms; mol.basis = a.basis; mol.charge = chg
            mol.spin = nelec % 2          # 0 = closed shell, 1 = one unpaired
            mol.verbose = 0; mol.max_memory = a.memory
            mol.build()
            mf = (dft.UKS(mol) if mol.spin else dft.RKS(mol)).density_fit()
            mf.xc = a.functional; mf.max_cycle = 80
            # The GFN2 reference values were computed in implicit water. Running
            # DFT in vacuum would conflate method difference with environment
            # difference - measured on a test molecule, that inflates the dipole
            # discrepancy by ~28% while barely touching orbital energies.
            if EPS[a.solvent] is not None:
                mf = mf.ddCOSMO()
                mf.with_solvent.eps = EPS[a.solvent]
            e = mf.kernel()
            if mol.spin:                       # UKS returns per-spin arrays
                eo = np.concatenate([mf.mo_energy[0][mf.mo_occ[0] > 0],
                                     mf.mo_energy[1][mf.mo_occ[1] > 0]])
                ev = np.concatenate([mf.mo_energy[0][mf.mo_occ[0] == 0],
                                     mf.mo_energy[1][mf.mo_occ[1] == 0]])
                homo, lumo = eo.max() * 27.2114, ev.min() * 27.2114
            else:
                occ = mf.mo_occ > 0
                homo = mf.mo_energy[occ].max() * 27.2114
                lumo = mf.mo_energy[~occ].min() * 27.2114
            row.update(n_atoms=n, nao=mol.nao, charge=chg, dft_energy_Ha=e,
                       dft_homo_eV=homo, dft_lumo_eV=lumo, dft_gap_eV=lumo-homo,
                       dft_dipole_D=float(np.linalg.norm(
                           mf.dip_moment(unit="Debye", verbose=0))),
                       converged=int(bool(mf.converged)))
        except MemoryError:
            row["error"] = "MemoryError - lower --threads or raise --memory"
        except Exception as ex:
            row["error"] = f"{type(ex).__name__}: {ex}"[:200]
        row["seconds"] = round(time.time() - t0, 1)
        w.writerow(row); fh.flush()
        status = "ok" if not row["error"] else "FAILED"
        print(f"  [{i}/{len(todo)}] {key[:14]}  {row['seconds']:7.1f}s  {status}"
              f"{'  '+row['error'] if row['error'] else ''}", flush=True)
print(f"\ndone in {(time.time()-t_start)/60:.1f} min -> {a.out}")
