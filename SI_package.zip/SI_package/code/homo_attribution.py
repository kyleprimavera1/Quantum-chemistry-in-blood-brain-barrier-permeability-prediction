#!/usr/bin/env python3
"""Which electronic descriptor actually carries the gain?

Set (b) - homo, lumo, gap, dipole - adds about +0.010 AUC over classical under
gradient boosting. The manuscript attributes most of that to HOMO. That claim
has been carried on permutation importance from an earlier run; this re-derives
it directly by adding each descriptor alone and by dropping each in turn, which
is the comparison the claim actually needs.

Same folds and same model as the equivalence analysis, so the numbers are
directly comparable to it.
"""
import numpy as np, pandas as pd
from sklearn.model_selection import GroupKFold
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import roc_auc_score

R = "/home/kyle/research"
S = "/tmp/claude-1000/-home-kyle/78e5d65d-9177-439c-9c5b-949373a48827/scratchpad/l4final"
base = pd.read_csv(f"{R}/results/descriptors_full.csv"); base = base[base.ok == 1]
C = [c for c in base.columns if c.startswith("c_")]
dft = pd.read_csv(f"{S}/dft_results_merged.csv")
dft = dft[(dft.converged == 1) & (dft.error.isna() | (dft.error == ""))]
d = base[["inchikey","label","scaffold"]+C].merge(dft, on="inchikey").reset_index(drop=True)
y, g = d.label.values, d.scaffold.values
FOLDS = list(GroupKFold(n_splits=5).split(np.zeros(len(d)), y, g))
E = {"homo":"dft_homo_eV","lumo":"dft_lumo_eV","gap":"dft_gap_eV","dipole":"dft_dipole_D"}

def auc(feats):
    X = d[feats].values.astype(float); p = np.zeros(len(d))
    for tr, te in FOLDS:
        m = HistGradientBoostingClassifier(max_iter=300, learning_rate=.08,
                                           max_leaf_nodes=31, random_state=0)
        m.fit(X[tr], y[tr]); p[te] = m.predict_proba(X[te])[:, 1]
    return roc_auc_score(y, p)

a0 = auc(C); print("classical only                 %.4f" % a0, flush=True)
aall = auc(C + list(E.values()))
print("classical + all four electronic %.4f  (%+.4f)\n" % (aall, aall - a0), flush=True)
print("%-10s %-22s %-22s" % ("descriptor", "ADDED ALONE (vs cls)", "DROPPED (vs all four)"))
for k, c in E.items():
    add = auc(C + [c])
    drop = auc(C + [v for kk, v in E.items() if kk != k])
    print("%-10s %.4f (%+.4f)      %.4f (%+.4f)"
          % (k, add, add - a0, drop, drop - aall), flush=True)
print("\nlinear correlation of each with the label (for contrast):")
for k, c in E.items():
    print("  %-8s r = %+.4f" % (k, np.corrcoef(d[c], y)[0, 1]))
