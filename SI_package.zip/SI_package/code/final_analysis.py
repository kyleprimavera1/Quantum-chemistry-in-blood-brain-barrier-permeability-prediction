#!/usr/bin/env python3
"""Everything still blocking submission, in one pass over one fold assignment.

The central question is R25: the paper's +0.0216 is an increment over eleven
RDKit descriptors, and the literature reports Morgan fingerprints beating
physicochemical descriptors on this very benchmark. If the quantum gain does not
survive a fingerprint-augmented baseline, the paper's headline claim has to be
restated. That is tested here rather than argued.

Predictions for EVERY arm are saved, so the figure and the applicability-domain
sensitivity can be regenerated without refitting anything again.
"""
import json, time
import numpy as np, pandas as pd
from sklearn.model_selection import GroupKFold
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import roc_auc_score, average_precision_score
from rdkit import Chem, RDLogger
from rdkit.Chem import rdFingerprintGenerator
RDLogger.DisableLog("rdApp.*")

R = "/home/kyle/research"; RNG = np.random.default_rng(0)
base = pd.read_csv(f"{R}/results/descriptors_full.csv"); base = base[base.ok == 1]
C = [c for c in base.columns if c.startswith("c_")]
Q1 = ["q_gsolv_water","q_gsolv_oct","q_dg_transfer","q_gap","q_etot","q_homo","q_lumo","q_dipole"]
def lvl(path, tag):
    d = pd.read_csv(path); d = d[d.ok == 1]
    q = [c for c in d.columns if c.startswith("q_")]
    return d[["inchikey"] + q].rename(columns={c: f"{c}_{tag}" for c in q})
d = (base[["inchikey","smiles","label","scaffold"] + C + Q1]
     .merge(lvl(f"{R}/results/ladder_L2.csv","L2"), on="inchikey")
     .merge(lvl(f"{R}/results/ladder_L3.csv","L3"), on="inchikey")).reset_index(drop=True)
Q2 = [c for c in d.columns if c.endswith("_L2")]; Q3 = [c for c in d.columns if c.endswith("_L3")]
y, g = d.label.values, d.scaffold.values
print("n = %d  scaffolds = %d" % (len(d), d.scaffold.nunique()), flush=True)

NBITS = 1024
gen = rdFingerprintGenerator.GetMorganGenerator(radius=2, fpSize=NBITS)
t0 = time.time()
FP = np.zeros((len(d), NBITS), dtype=np.int8)
for i, smi in enumerate(d.smiles):
    m = Chem.MolFromSmiles(smi)
    if m is None: continue
    FP[i] = gen.GetFingerprintAsNumPy(m)      # already uint8 of length fpSize
print("Morgan ECFP4 %d bits computed in %.1f s; mean density %.3f"
      % (NBITS, time.time()-t0, FP.mean()), flush=True)
np.save(f"{R}/results/morgan_fp.npy", FP)

FOLDS = list(GroupKFold(n_splits=5).split(np.zeros(len(d)), y, g))

def oof(X, tag):
    p = np.zeros(len(d)); t = time.time()
    for i, (tr, te) in enumerate(FOLDS):
        m = HistGradientBoostingClassifier(max_iter=300, learning_rate=.08,
                                           max_leaf_nodes=31, random_state=0)
        m.fit(X[tr], y[tr]); p[te] = m.predict_proba(X[te])[:, 1]
        print("   [%s] fold %d/5  %.0fs" % (tag, i+1, time.time()-t), flush=True)
    return p

def boot(pa, pb):
    o = []; idx = np.arange(len(y))
    for _ in range(2000):
        b = RNG.choice(idx, len(idx), replace=True)
        if len(np.unique(y[b])) < 2: continue
        o.append(roc_auc_score(y[b], pb[b]) - roc_auc_score(y[b], pa[b]))
    return np.percentile(o, [2.5, 97.5])

M = d[C].values.astype(float)
ARMS = {
  "classical":        M,
  "classical+L1":     d[C+Q1].values.astype(float),
  "classical+L2":     d[C+Q2].values.astype(float),
  "classical+L3":     d[C+Q3].values.astype(float),
  "FP":               FP.astype(float),
  "classical+FP":     np.hstack([M, FP]),
  "classical+FP+L1":  np.hstack([M, d[Q1].values.astype(float), FP]),
}
P = {}
for nm, X in ARMS.items():
    P[nm] = oof(X, nm)
np.savez(f"{R}/results/all_oof.npz", y=y, **P)

print("\n%-20s %-9s %-9s" % ("arm", "ROC-AUC", "PR-AUC"), flush=True)
for nm in ARMS:
    print("%-20s %-9.4f %-9.4f" % (nm, roc_auc_score(y, P[nm]), average_precision_score(y, P[nm])), flush=True)

print("\n=== THE QUESTION: does the quantum gain survive a fingerprint baseline? ===", flush=True)
for a_, b_, lab in (("classical","classical+L1","QM over classical (the headline)"),
                    ("classical","classical+FP","fingerprints over classical"),
                    ("classical+FP","classical+FP+L1","QM over classical+fingerprints")):
    dl = roc_auc_score(y, P[b_]) - roc_auc_score(y, P[a_]); lo, hi = boot(P[a_], P[b_])
    print("  %-38s %+.4f  [%+.4f, %+.4f]  %s"
          % (lab, dl, lo, hi, "EXCLUDES ZERO" if lo > 0 or hi < 0 else "spans zero"), flush=True)

out = {nm: dict(auc=roc_auc_score(y, P[nm]), pr=average_precision_score(y, P[nm])) for nm in ARMS}
json.dump(out, open(f"{R}/results/final_analysis.json","w"), indent=2)
print("\nwrote results/final_analysis.json and results/all_oof.npz", flush=True)
