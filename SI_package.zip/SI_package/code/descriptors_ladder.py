#!/usr/bin/env python3
"""Ladder levels 2 and 3: three solvents, optional conformer ensemble.

Level 2  --nconf 1    single conformer, water/octanol/hexadecane
Level 3  --nconf 10   Boltzmann-weighted conformer ensemble, same three solvents

Adds a first-principles analogue of Seiler's dlogP:
    dlogP ~ dG_hexadecane - dG_octanol
Positive => the molecule gains more from octanol's H-bonding than from a bare
alkane, i.e. high hydrogen-bonding capacity, which opposes BBB penetration.

Success is judged by EXIT CODE. xtb writes "normal termination" to stderr, and
"abnormal termination" contains that string as a substring - never grep for it.
"""
import argparse, csv, os, re, subprocess, sys, tempfile, time
import numpy as np, pandas as pd
from multiprocessing import Pool
from rdkit import Chem, RDLogger
from rdkit.Chem import AllChem, Descriptors, Crippen

RDLogger.DisableLog("rdApp.*")
HARTREE_KCAL = 627.5094740631
KT_EH = 3.166811563e-6 * 298.15          # k_B T at 298.15 K, in Hartree
SOLVENTS = ("water", "octanol", "hexadecane")

RE_GSOLV = re.compile(r"->\s*Gsolv\s+(-?\d+\.\d+)")
RE_GAP   = re.compile(r"HOMO-LUMO GAP\s+(-?\d+\.\d+)\s*eV", re.I)
RE_ETOT  = re.compile(r"TOTAL ENERGY\s+(-?\d+\.\d+)\s*Eh", re.I)
RE_HOMO  = re.compile(r"^\s*\d+\s+[\d.]+\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s*\(HOMO\)", re.M)
RE_LUMO  = re.compile(r"^\s*\d+\s+(?:[\d.]+\s+)?(-?\d+\.\d+)\s+(-?\d+\.\d+)\s*\(LUMO\)", re.M)
# The occupancy column is OPTIONAL: xtb prints "25 0.0000 -0.43 -11.74 (LUMO)"
# in some outputs and omits the 0.0000 in others. Requiring exactly two numeric
# fields silently fails on the first form, and the caller then writes a LUMO of
# 0.0 eV - roughly 7 eV from any real value - into the descriptor table.

META  = ["inchikey", "name", "smiles", "label", "logBB", "charge", "n_heavy",
         "mw", "scaffold"]
CLASS = ["c_mw","c_clogp","c_tpsa","c_hbd","c_hba","c_rotb","c_arom","c_fcsp3",
         "c_heavy","c_mr","c_charge"]
QM    = ["q_gsolv_water","q_gsolv_oct","q_gsolv_hex","q_dg_oct","q_dg_hex",
         "q_dlogp","q_gap","q_homo","q_lumo","q_dipole","q_nconf",
         "q_espread","q_dipspread"]
FIELDS = META + CLASS + QM + ["ok", "err"]


def dipole(txt):
    i = txt.find("molecular dipole:")
    if i < 0: return None
    for line in txt[i:i+600].splitlines():
        if line.strip().startswith("full:"):
            try: return float(line.split()[-1])
            except Exception: return None
    return None


def xtb(args, cwd, env, timeout=1800):
    r = subprocess.run(["xtb"] + args, cwd=cwd, env=env, capture_output=True,
                       text=True, timeout=timeout)
    return r.stdout, r.returncode          # exit code, never stderr text


def write_xyz(mol, cid, path):
    c = mol.GetConformer(cid)
    with open(path, "w") as f:
        f.write(f"{mol.GetNumAtoms()}\n\n")
        for a in mol.GetAtoms():
            p = c.GetAtomPosition(a.GetIdx())
            f.write(f"{a.GetSymbol()} {p.x:.6f} {p.y:.6f} {p.z:.6f}\n")


def classical(m):
    return dict(c_mw=Descriptors.MolWt(m), c_clogp=Crippen.MolLogP(m),
                c_tpsa=Descriptors.TPSA(m), c_hbd=Descriptors.NumHDonors(m),
                c_hba=Descriptors.NumHAcceptors(m),
                c_rotb=Descriptors.NumRotatableBonds(m),
                c_arom=Descriptors.NumAromaticRings(m),
                c_fcsp3=Descriptors.FractionCSP3(m), c_heavy=m.GetNumHeavyAtoms(),
                c_mr=Crippen.MolMR(m), c_charge=Chem.GetFormalCharge(m))


def one(rec):
    key, smi, chg, nconf = rec
    out = {"idx": key, "ok": 0, "err": ""}
    try:
        m0 = Chem.MolFromSmiles(smi)
        if m0 is None:
            out["err"] = "parse"; return out
        out.update(classical(m0))
        m = Chem.AddHs(m0)
        ps = AllChem.ETKDGv3(); ps.pruneRmsThresh = 0.5; ps.randomSeed = 0xC0FFEE
        cids = list(AllChem.EmbedMultipleConfs(m, numConfs=nconf, params=ps))
        if not cids:
            ps2 = AllChem.ETKDGv3(); ps2.useRandomCoords = True
            ps2.maxIterations = 2000; ps2.pruneRmsThresh = 0.5
            cids = list(AllChem.EmbedMultipleConfs(m, numConfs=nconf, params=ps2))
        if not cids:
            out["err"] = "embed"; return out
        AllChem.MMFFOptimizeMoleculeConfs(m, maxIters=500)

        env = dict(os.environ, OMP_NUM_THREADS="1", MKL_NUM_THREADS="1")
        confs = []
        for cid in cids:
            with tempfile.TemporaryDirectory() as d:
                write_xyz(m, cid, f"{d}/c.xyz")
                base = ["c.xyz", "--gfn", "2", "--chrg", str(chg)]
                w, rc = xtb(base + ["--opt", "--alpb", "water"], d, env)
                if rc != 0: continue
                gw, et = RE_GSOLV.findall(w), RE_ETOT.search(w)
                if not (gw and et): continue
                geom = "xtbopt.xyz" if os.path.exists(f"{d}/xtbopt.xyz") else "c.xyz"
                sp = {}
                for s in ("octanol", "hexadecane"):
                    o, rco = xtb([geom, "--gfn", "2", "--chrg", str(chg),
                                  "--alpb", s], d, env)
                    g = RE_GSOLV.findall(o)
                    if rco != 0 or not g: break
                    sp[s] = float(g[-1])
                if len(sp) != 2: continue
                gap, ho, lu = RE_GAP.search(w), RE_HOMO.search(w), RE_LUMO.search(w)
                confs.append(dict(
                    e=float(et.group(1)), gw=float(gw[-1]),
                    go=sp["octanol"], gh=sp["hexadecane"],
                    gap=float(gap.group(1)) if gap else np.nan,
                    homo=float(ho.group(2)) if ho else np.nan,
                    lumo=float(lu.group(2)) if lu else np.nan,
                    dip=dipole(w)))
        if not confs:
            out["err"] = "xtb_all_conformers_failed"; return out

        E = np.array([c["e"] for c in confs])
        wts = np.exp(-(E - E.min()) / KT_EH); wts /= wts.sum()
        avg = lambda k: float(np.nansum(wts * np.array(
            [c[k] if c[k] is not None else np.nan for c in confs], dtype=float)))
        gw_, go_, gh_ = (avg("gw") * HARTREE_KCAL, avg("go") * HARTREE_KCAL,
                         avg("gh") * HARTREE_KCAL)
        dips = np.array([c["dip"] for c in confs if c["dip"] is not None], dtype=float)
        out.update(
            q_gsolv_water=gw_, q_gsolv_oct=go_, q_gsolv_hex=gh_,
            q_dg_oct=go_ - gw_,                       # transfer water -> octanol
            q_dg_hex=gh_ - gw_,                       # transfer water -> alkane
            q_dlogp=(gh_ - gw_) - (go_ - gw_),        # Seiler dlogP analogue
            q_gap=avg("gap"), q_homo=avg("homo"), q_lumo=avg("lumo"),
            q_dipole=avg("dip"), q_nconf=len(confs),
            q_espread=float((E.max() - E.min()) * HARTREE_KCAL),
            q_dipspread=float(dips.max() - dips.min()) if len(dips) > 1 else 0.0,
            ok=1)
    except subprocess.TimeoutExpired:
        out["err"] = "timeout"
    except Exception as e:
        out["err"] = type(e).__name__
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", default="/home/kyle/research/results/descriptors_full.csv")
    ap.add_argument("--out", required=True)
    ap.add_argument("--nconf", type=int, required=True)
    ap.add_argument("--n", type=int, default=1500)
    ap.add_argument("--procs", type=int, default=3)
    ap.add_argument("--seed", type=int, default=7)
    a = ap.parse_args()

    src = pd.read_csv(a.source)
    src = src[src.ok == 1].reset_index(drop=True)
    # Fixed stratified subset -> levels 2 and 3 see IDENTICAL molecules, so every
    # comparison across the ladder is paired.
    parts = []
    for _l, g in src.groupby("label"):
        k = max(1, int(round(a.n * len(g) / len(src))))
        parts.append(g.sample(min(k, len(g)), random_state=a.seed))
    sub = pd.concat(parts).reset_index(drop=True)

    done = set()
    if os.path.exists(a.out) and os.path.getsize(a.out) > 0:
        try: done = set(pd.read_csv(a.out).inchikey.astype(str))
        except Exception: pass
    todo = sub[~sub.inchikey.astype(str).isin(done)]
    print(f"subset {len(sub)}  done {len(done)}  remaining {len(todo)}  "
          f"nconf={a.nconf}  procs={a.procs}", flush=True)
    if todo.empty:
        print("nothing to do"); return 0

    meta = {str(r.inchikey): r for _, r in todo.iterrows()}
    recs = [(str(r.inchikey), r.smiles, int(r.charge), a.nconf)
            for _, r in todo.iterrows()]

    new = not os.path.exists(a.out) or os.path.getsize(a.out) == 0
    t0, nok = time.time(), 0
    with open(a.out, "a", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=FIELDS, extrasaction="ignore")
        if new: w.writeheader(); fh.flush()
        with Pool(a.procs) as pool:
            for i, res in enumerate(pool.imap_unordered(one, recs, chunksize=1), 1):
                mrow = meta[res["idx"]]
                row = {k: mrow.get(k) for k in META}
                row["inchikey"] = res["idx"]
                row.update({k: res.get(k) for k in CLASS + QM})
                row["ok"], row["err"] = res.get("ok", 0), res.get("err", "")
                w.writerow(row); fh.flush(); os.fsync(fh.fileno())
                nok += row["ok"]
                if i % 20 == 0 or i == len(recs):
                    el = time.time() - t0
                    # Guarded: this path exists only on the Raspberry Pi. Unguarded it crashes

                    # any run on other hardware at the first progress report - which is exactly

                    # what killed the remote recompute after 20 of 77 molecules.

                    t = (open("/sys/class/thermal/thermal_zone0/temp").read()

                         if os.path.exists("/sys/class/thermal/thermal_zone0/temp") else "0")
                    print(f"  {i}/{len(recs)} ok={nok} {el/i:.1f}s/mol "
                          f"ETA {(len(recs)-i)*el/i/3600:.1f}h "
                          f"{int(t)/1000:.1f}C", flush=True)
    print(f"\ndone {nok}/{len(recs)} in {(time.time()-t0)/3600:.2f} h", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
