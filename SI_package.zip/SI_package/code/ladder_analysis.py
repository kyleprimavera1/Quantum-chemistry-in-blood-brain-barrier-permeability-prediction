#!/usr/bin/env python3
"""Ladder comparison: classical vs level-1 QM vs level-2 QM, same molecules."""
import numpy as np, pandas as pd
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import roc_auc_score

RNG = np.random.default_rng(0)
l1 = pd.read_csv("results/descriptors_full.csv"); l1 = l1[l1.ok == 1]
l2 = pd.read_csv("results/ladder_L2.csv");        l2 = l2[l2.ok == 1]
L1Q = [c for c in l1.columns if c.startswith("q_")]
l1 = l1[["inchikey"] + L1Q].rename(columns={c: c + "_L1" for c in L1Q})
d = l2.merge(l1, on="inchikey", how="inner").reset_index(drop=True)
C   = [c for c in d.columns if c.startswith("c_")]
Q1  = [c for c in d.columns if c.endswith("_L1")]
Q2  = [c for c in d.columns if c.startswith("q_") and not c.endswith("_L1")]
print(f"merged n = {len(d)}   scaffolds = {d.scaffold.nunique()}")
print(f"level-1 QM features: {len(Q1)}   level-2 QM features: {len(Q2)}")
print(f"  new at level 2: {[c for c in Q2 if c in ('q_gsolv_hex','q_dg_hex','q_dlogp')]}\n")
y, g = d.label.values, d.scaffold.values

def oof(feats, kind):
    X = d[feats].values; p = np.zeros(len(d))
    for tr, te in GroupKFold(n_splits=5).split(X, y, g):
        m = (make_pipeline(SimpleImputer(strategy="median"), StandardScaler(),
                           LogisticRegression(max_iter=5000, class_weight="balanced"))
             if kind == "linear" else
             HistGradientBoostingClassifier(max_iter=300, learning_rate=.08,
                                            max_leaf_nodes=31, random_state=0))
        m.fit(X[tr], y[tr]); p[te] = m.predict_proba(X[te])[:, 1]
    return p

def boot(pa, pb, lab):
    dd = []; idx = np.arange(len(y))
    for _ in range(2000):
        b = RNG.choice(idx, len(idx), replace=True)
        if len(np.unique(y[b])) < 2: continue
        dd.append(roc_auc_score(y[b], pb[b]) - roc_auc_score(y[b], pa[b]))
    lo, hi = np.percentile(dd, [2.5, 97.5])
    print(f"    {lab}: {roc_auc_score(y,pb)-roc_auc_score(y,pa):+.4f}  "
          f"CI [{lo:+.4f}, {hi:+.4f}]  "
          f"{'EXCLUDES ZERO' if lo>0 or hi<0 else 'spans zero'}")

for kind in ("linear", "gb"):
    print(f"[{kind}]")
    p0 = oof(C, kind); p1 = oof(C + Q1, kind); p2 = oof(C + Q2, kind)
    for nm, p in (("classical", p0), ("+ level-1 QM", p1), ("+ level-2 QM", p2)):
        print(f"  {nm:16s} AUC {roc_auc_score(y,p):.4f}")
    boot(p0, p1, "L1 vs classical")
    boot(p0, p2, "L2 vs classical")
    boot(p1, p2, "L2 vs L1      ")
    print()

print("new level-2 descriptors, single-feature AUC (gb, scaffold CV)")
for f in ("q_dg_hex", "q_dlogp", "q_gsolv_hex", "q_dg_oct", "c_tpsa"):
    if f in d.columns:
        print(f"  {f:14s} {roc_auc_score(y, oof([f],'gb')):.4f}")
print("\ndlogP sanity (should track H-bonding proxies):")
for f in ("c_hbd", "c_hba", "c_tpsa"):
    print(f"  corr(q_dlogp, {f}) = {np.corrcoef(d.q_dlogp, d[f])[0,1]:+.3f}")
