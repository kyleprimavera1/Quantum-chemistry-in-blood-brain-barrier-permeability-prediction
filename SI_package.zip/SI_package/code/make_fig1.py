#!/usr/bin/env python3
"""Regenerate Figure 1 from saved out-of-fold predictions.

The shipped figure was built on 12 September from a fold assignment that has
since been superseded, so it disagrees with the table it illustrates. Rebuilt
here from results/all_oof.npz so figure and text cannot drift apart again.
"""
import json
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, roc_auc_score

R = "/home/kyle/research"
z = np.load(f"{R}/results/all_oof.npz"); y = z["y"]
J = json.load(open(f"{R}/results/final_analysis.json"))
# Greyscale throughout: the four arms are separated by line style as well as
# tone, so the panel survives black-and-white printing and photocopying.
ARMS = [("classical","Classical (11)","#000000","-"),
        ("classical+L1","+ Level 1 QM","#444444","--"),
        ("classical+L2","+ Level 2 QM","#777777","-."),
        ("classical+L3","+ Level 3 QM","#AAAAAA",":")]
fig, ax = plt.subplots(1, 3, figsize=(13.5, 4.2))

for k, lab, col, ls in ARMS:
    fpr, tpr, _ = roc_curve(y, z[k])
    ax[0].plot(fpr, tpr, color=col, ls=ls, lw=1.6,
               label="%s  %.4f" % (lab, roc_auc_score(y, z[k])))
ax[0].plot([0,1],[0,1], color="#999999", lw=1, ls=":")
ax[0].set_xlabel("False positive rate"); ax[0].set_ylabel("True positive rate")
ax[0].set_title("A   ROC, scaffold-grouped CV", loc="left", fontsize=11)
ax[0].legend(frameon=False, fontsize=8, loc="lower right")

cost = [1e-6, 7.6, 10.4, 53.0]                      # seconds of quantum time per molecule
auc = [J[k]["auc"] for k,_,_,_ in ARMS]
ax[1].semilogx(cost, auc, "o-", color="#000000", lw=1.6, ms=6)
for c, a_, (_, lab, _, _) in zip(cost, auc, ARMS):
    ax[1].annotate(lab, (c, a_), textcoords="offset points", xytext=(6, -10), fontsize=8)
ax[1].set_xlabel("quantum cost per molecule (s, log scale)"); ax[1].set_ylabel("ROC-AUC")
ax[1].set_title("B   Cost–accuracy frontier", loc="left", fontsize=11)

names = ["L1 vs\nclassical", "L2 vs L1", "L3 vs L2"]
vals = [J["classical+L1"]["auc"]-J["classical"]["auc"],
        J["classical+L2"]["auc"]-J["classical+L1"]["auc"],
        J["classical+L3"]["auc"]-J["classical+L2"]["auc"]]
cis = [(0.0164,0.0268), (-0.0002,0.0070), (-0.0031,0.0040)]
for i,(v,(lo,hi)) in enumerate(zip(vals,cis)):
    ax[2].errorbar(i, v, yerr=[[v-lo],[hi-v]], fmt="o", color="#000000",
                   ecolor="#000000", capsize=4, ms=6)
ax[2].axhline(0, color="#999999", lw=1, ls=":")
ax[2].set_xticks(range(3)); ax[2].set_xticklabels(names, fontsize=8)
ax[2].set_ylabel("ΔAUC"); ax[2].set_title("C   Per-rung effect size (95% CI)", loc="left", fontsize=11)
for a_ in ax: a_.spines[["top","right"]].set_visible(False)
plt.tight_layout()
plt.savefig(f"{R}/manuscript/figure1.png", dpi=400)
print("wrote manuscript/figure1.png at 400 dpi")
