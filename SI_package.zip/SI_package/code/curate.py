#!/usr/bin/env python3
"""Curate B3DB into a clean modelling set. Records counts at every filter step."""
import pandas as pd
from rdkit import Chem, RDLogger
from rdkit.Chem import Descriptors
from rdkit.Chem.MolStandardize import rdMolStandardize
from rdkit.Chem.Scaffolds import MurckoScaffold

RDLogger.DisableLog("rdApp.*")
SRC = "/home/kyle/research/data/B3DB_classification.tsv"
OUT = "/home/kyle/research/data/curated.csv"
ALLOWED = set("H B C N O F Si P S Cl Br I".split())
MAX_HEAVY = 70          # bounds xtb cost; count reported below

log = []
def step(name, n): log.append((name, n)); print(f"  {name:44s} {n:6d}")

df = pd.read_csv(SRC, sep="\t")
print("CURATION FLOW"); print("-"*54)
step("records in B3DB", len(df))

df = df.dropna(subset=["SMILES", "BBB+/BBB-"])
step("with SMILES and label", len(df))

lfc = rdMolStandardize.LargestFragmentChooser()
rows, bad_parse, bad_elem, too_big = [], 0, 0, 0
for _, r in df.iterrows():
    m = Chem.MolFromSmiles(r["SMILES"])
    if m is None:
        bad_parse += 1; continue
    m = lfc.choose(m)                     # strip counterions / salts
    m = rdMolStandardize.Normalize(m)
    if m is None or m.GetNumAtoms() == 0:
        bad_parse += 1; continue
    els = {a.GetSymbol() for a in m.GetAtoms()}
    if not els <= ALLOWED:
        bad_elem += 1; continue
    nheavy = m.GetNumHeavyAtoms()
    if nheavy > MAX_HEAVY or nheavy < 5:
        too_big += 1; continue
    try:
        scaf = MurckoScaffold.MurckoScaffoldSmiles(mol=m)
    except Exception:
        scaf = ""
    rows.append(dict(
        name=r["compound_name"],
        smiles=Chem.MolToSmiles(m),
        inchikey=Chem.MolToInchiKey(m),
        label=1 if str(r["BBB+/BBB-"]).strip() == "BBB+" else 0,
        logBB=r.get("logBB"),
        charge=Chem.GetFormalCharge(m),
        n_heavy=nheavy,
        mw=Descriptors.MolWt(m),
        scaffold=scaf if scaf else "ACYCLIC",
    ))

step("parsed and standardised", len(rows))
print(f"    (dropped: {bad_parse} unparseable, {bad_elem} exotic elements, {too_big} size out of range)")

c = pd.DataFrame(rows)

# Duplicates: same structure appearing more than once.
dupe_groups = c.groupby("inchikey")["label"].nunique()
conflicted = set(dupe_groups[dupe_groups > 1].index)
c = c[~c.inchikey.isin(conflicted)]
step(f"after dropping {len(conflicted)} label-conflicted structures", len(c))

c = c.drop_duplicates(subset="inchikey", keep="first")
step("after deduplication (unique structures)", len(c))

c.to_csv(OUT, index=False)
print("-"*54)
print(f"\nClass balance:  BBB+ {int(c.label.sum())}  ({c.label.mean()*100:.1f}%)"
      f"   BBB- {int((1-c.label).sum())}")
print(f"Unique Murcko scaffolds: {c.scaffold.nunique()}")
print(f"Charged species (non-zero formal charge): {(c.charge != 0).sum()}")
print(f"Heavy atoms: median {c.n_heavy.median():.0f}, max {c.n_heavy.max()}")
print(f"logBB available for: {c.logBB.notna().sum()} compounds")
print(f"\nwrote {OUT}")
