# Level 4 DFT control — FINAL dataset

**2026-09-15. Supersedes `level4_interim_partial.zip` (3,335 rows).**

---

## 1. What's enclosed

```
dft_results_merged.csv     7,572 rows x 35 columns   <- the dataset
run_dft.py                 the driver that produced every row
merge_results.py           the merge, with its refuse-to-write checks
evidence/merge_report.txt  merge provenance and integrity output
evidence/validation.txt    post-hoc checks run against the merged file
```

## 2. Coverage and integrity

**7,572 / 7,572 molecules. 100%.** Zero error rows, zero non-converged SCF,
one solvation model throughout (`SMD`), one backend (`gpu`).

B3LYP/def2-SVP with density fitting, SMD continuum solvation, four single points
per molecule: gas, water (eps 78.3553), 1-octanol (9.8629), n-hexadecane (2.0402).

The identity `dft_dlogp_analogue_kcal == dft_dg_transfer_hxd_kcal -
dft_dg_transfer_kcal` holds on every row with zero violations.

## 3. Two schema traps — please read before writing any merge code

**Positional reads break.** Columns 1–18 are byte-identical to the v2 schema, but
**v2's column 19 (`error`) is now column 35**. Position 19 is `dft_etot_hxd_Eh`.
Anything indexing by position silently reads a Hartree energy where it expects an
error string. Select by name.

**The water phase has no suffix.** Gas, octanol and hexadecane electronic columns
are suffixed (`dft_homo_eV_gas`, `_oct`, `_hxd`), but the water-phase ones are bare:
`dft_homo_eV`, `dft_lumo_eV`, `dft_gap_eV`, `dft_dipole_D`. This is deliberate — it
preserves v2 compatibility — but it is an easy thing to get wrong, as you noted in
your reply to the interim package. Kept rather than changed, and documented here.

## 4. The SMD repair, validated at full n

Your REPLY_v3 §5 asked for one check: if SMD still showed ~0% water-preferring
compounds at n≈500, something was wrong, because a drug-like set should contain a
polar tail that genuinely prefers water.

```
water-preferring (dG_transfer > 0)
  C-PCM (withdrawn)   0.0%     could not place ANY compound on the lipophilic side
  GFN2/ALPB          15.6%
  SMD (this file)    20.5%     1,555 of 7,572
```

And the degeneracy that forced the restart is gone:

```
independent variance in dG_transfer
  C-PCM               0.64%
  SMD, n=474 interim 63.3%
  SMD, n=7,572       63.4%
```

Stable from the interim to the full set. (That statistic is 1−r² of `dG_transfer`
against `Gsolv_water` — how much of the transfer free energy is *not* a rescaling
of the aqueous term. Not to be confused with 1−r² between the two `Gsolv` columns,
which is 6.1%; the two solvation energies are still strongly correlated, as they
should be. What changed is that their difference now carries information.)

## 5. Cross-machine control — scope stated honestly

The run was distributed across six GPUs: V100 32GB, two A100 SXM4 40GB, H100 80GB,
A800 80GB PCIe, and an A100 SXM4 80GB. Nineteen molecules were computed on more
than one machine, and agreement is at SCF convergence noise:

```
max spread over duplicates   7.1e-10 Eh (total energy)
                             6.8e-09 kcal/mol (solvation free energy)
                             9.1e-10 eV (HOMO)
```

**The duplicates cover only three of the six machines** — the pairs are
a100/v100 (5 molecules), a100b/v100 (3) and a100/a100b (11). They arose
accidentally, where a rebalance overlapped a snapshot, so they were never
distributed by design. The H100, A800 and A100-SXM4-80GB arms have **no**
duplicate coverage. The control therefore demonstrates V100-vs-A100 equivalence
and does not, by itself, extend to the other three. If that matters for the
methods claim, a deliberate 20-molecule replicate would close it cheaply.

Suggested wording, narrower than what I sent with the interim package:

> The production run was distributed across six GPUs. Nineteen molecules were
> computed on more than one machine (V100/A100 pairs); agreement was within
> 7.1e-10 Eh in total energy, 6.8e-9 kcal/mol in solvation free energy and
> 9.1e-10 eV in HOMO, i.e. at the level of SCF convergence noise.

## 6. What changed since the interim package

- 3,335 → 7,572 rows, complete.
- 56 molecules (105–119 atoms) that had failed with CUDA OOM on the 16 GB V100
  were recovered on 80 GB cards. They are in the file, converged, no method
  deviation — same driver, same SMD four-point protocol.
- Provenance: v100 2,602 | a100 2,446 | a100b 2,328 | h100 140 | 80GB cleanup 56.

## 7. The ddCOSMO supplement is NOT in this package

The B3LYP/ddCOSMO-vs-B3LYP/SMD comparison — same Hamiltonian, same geometries,
only the continuum model differing — **did not survive the run.** The sidecar was
launched on the V100's idle cores in the same minute its GPU shard completed, and
the shutdown watchdog destroyed the machine before any row was written. The twelve
`ddcosmo_sidecar_*.csv` files that exist contain headers only. That is my error,
not a computational failure.

It is recoverable: ~200 molecules, 4–6 CPU-hours on a high-core instance. It is
**not** required for tests (a), (b) or (c) — those are all DFT-vs-GFN2 on this
file. It bounds the solvation half of the confound, which the manuscript currently
handles as a stated limitation. Say the word and it can be run.

## 8. Limitations to carry forward

Your §5A caveat stands and should go in verbatim in substance: SMD's CDS terms are
empirically fitted to experimental transfer data via atomic surface tensions, so
the DFT arm's solvation is not first-principles either. ALPB is also parameterised,
so the two arms are now like-for-like in kind — which is the improvement — but the
limitations section should say so plainly rather than let a reader assume SMD is
ab initio. "Both arms use empirically parameterised continuum solvation,
differently fitted."

## 9. Unblocked

All three pre-declared tests can now run on this file:

- **(a)** all eight level-1 descriptors — the registered primary
- **(b)** the four electronic descriptors, water phase — free of the solvation confound, carrying 81% of the quantum gain
- **(c)** the ten informative level-2 descriptors — `gsolv_water`, `gsolv_oct`, `gsolv_hxd`, `dg_oct`, `dg_hxd`, `dlogp`, `gap`, `homo`, `lumo`, `dipole`

Scaffold-grouped 5-fold CV, paired bootstrap, equivalence margin |ΔAUC| < 0.010,
as registered. The four-phase electronic columns are present if you want to pursue
the solvent-induced HOMO shift as a secondary; that shift is near-orthogonal to the
water-phase HOMO (r shown in `evidence/validation.txt`), so it is not a rescaling.
